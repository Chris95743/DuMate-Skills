---
name: qianfan-knowledgebase
description: 操作千帆 AppBuilder 在线知识库（KnowledgeBase）。当用户要创建/查询/修改/删除知识库、导入网页URL或上传文件到知识库、查询或删除知识库文档时触发——包括"建个知识库""把这个网页导入知识库""上传文件到知识库""列一下我的知识库""删除某个文档"等。基于千帆 OpenAPI，仅需 Node 运行时和 APPBUILDER_TOKEN，无需安装任何 SDK。
---

# 千帆 AppBuilder 知识库

通过命令行操作千帆 AppBuilder 的在线知识库，效果与控制台一致。底层直接调用千帆 OpenAPI（`https://qianfan.baidubce.com/v2/knowledgeBase?Action=<Action>`），**零第三方依赖**，只用 Node 内置 `fetch`。

## 前置条件

1. **Node 18+**（脚本用到全局 `fetch`/`FormData`/`Blob`）。
2. **API Key（AppBuilder API Key，作为 Bearer token）**，获取地址：<https://console.bce.baidu.com/qianfan/ais/console/apiKey>（千帆控制台 → API Key）。提供两种方式，任选其一：
   - **临时（优先生效）**：设置环境变量。PowerShell `$env:APPBUILDER_TOKEN="你的Key"`；bash `export APPBUILDER_TOKEN="你的Key"`。适合 CI 或一次性使用。
   - **长期（一次保存，之后免传）**：`node scripts/kb.js set-token <你的Key>`。token 会存到 `~/.comate/qianfan-knowledgebase.token`（Windows：`C:\Users\<用户名>\.comate\...`）。清除用 `node scripts/kb.js clear-token`。

> **关于 token 存放**：环境变量优先于本地文件。本地文件位于**用户主目录**，刻意放在 skill 目录之外，因此**不会被打包进 zip、也不会被提交到仓库**——这条边界是硬性的：请勿把 key 写进 skill 目录或任何会进版本库的文件，否则一旦仓库公开即等于泄露密钥。
>
> 删除类操作（`delete` / `doc-delete`）不可逆，必须显式加 `--yes`。

## 命令用法

所有命令：`node scripts/kb.js <子命令> [参数]`，输出为格式化 JSON。运行 `node scripts/kb.js help` 查看全部。

### 知识库管理
```bash
# 新建知识库（默认 public 共享资源）
node scripts/kb.js create --name "我的知识库" --desc "说明"
# 用 BES/VDB 托管
node scripts/kb.js create --name kb --type bes --cluster-id <id> --es-user <u> --es-pass <p> --location bj

# 详情 / 列表 / 修改
node scripts/kb.js get <知识库ID>
node scripts/kb.js list --limit 10 --keyword 测试
node scripts/kb.js modify <知识库ID> --name 新名字 --desc 新描述

# 删除（不可逆，需 --yes）
node scripts/kb.js delete <知识库ID> --yes
```

### 文档管理
```bash
# 导入单个网页 URL
node scripts/kb.js doc-import <知识库ID> --url "https://example.com/a" --template default

# 上传本地文件（.doc/.docx/.pdf/.ppt/.pptx/.txt）
node scripts/kb.js doc-upload <知识库ID> --file ./manual.pdf --template custom

# 文档列表 / 删除文档（删除不可逆，需 --yes）
node scripts/kb.js doc-list <知识库ID> --limit 10
node scripts/kb.js doc-delete <知识库ID> <文档ID> --yes
```

### 检索（知识问答）
```bash
# 从知识库检索与问题最相关的切片
node scripts/kb.js search <知识库ID> --q "用户的问题" --top-k 5

# 可选：检索策略与得分阈值
node scripts/kb.js search <知识库ID> --q "问题" --type semantic --score 0.4
```
- `--q`：检索内容（必填），最长 1024 字符
- `--top-k`：返回条数，默认 6，范围 1–40
- `--type`：`fulltext`（全文）| `semantic`（语义）| `hybrid`（混合）
- `--score`：综合得分阈值，范围 0–1，默认 0.4
- 返回 `chunks[]`，每条含 `content`（命中文本）、`rerank/recall` 得分和 `doc_info` 来源文档

## 切片 / 解析策略（进阶）

`doc-import` / `doc-upload` 默认用 `--template default`。需要自定义解析、切片、知识增强时，把完整的 `processOption` 写成 JSON 文件，用 `--config` 传入：

```bash
node scripts/kb.js doc-upload <知识库ID> --file ./x.pdf --config ./process.json
```

`process.json` 的字段结构与示例见 [reference.md](./reference.md)。

## 接口对照（底层 Action）

- create → `CreateKnowledgeBase`，get → `DescribeKnowledgeBase`，list → `DescribeKnowledgeBases`
- modify → `ModifyKnowledgeBase`，delete → `DeleteKnowledgeBase`
- doc-import → `CreateDocuments`，doc-upload → `UploadDocuments`（multipart）
- doc-list → `DescribeDocuments`，doc-delete → `DeleteDocument`

均为 `POST /v2/knowledgeBase?Action=<上述>`，Host `qianfan.baidubce.com`。

- search → `POST /v2/knowledgebases/search`（路径式接口，非 `?Action=`），Host 同上。

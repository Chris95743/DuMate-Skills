#!/usr/bin/env node
'use strict';

/*
 * 千帆 AppBuilder 知识库 CLI —— 零依赖，仅用 Node 内置能力（fetch/FormData/Blob）。
 * 底层直接调用 https://qianfan.baidubce.com/v2/knowledgeBase?Action=<Action>
 * 鉴权：环境变量 APPBUILDER_TOKEN（即 AppBuilder API Key，作为 Bearer token）。
 *
 * 用法见 `node kb.js help` 或同目录 ../SKILL.md
 */

const fs = require('fs');

const BASE = process.env.KB_API_BASE || 'https://qianfan.baidubce.com';
const TOKEN = process.env.APPBUILDER_TOKEN || '';

// ---- 参数解析 -------------------------------------------------------------
// 返回 { _: [位置参数...], flags: { key: value|true } }
function parseArgs(argv) {
  const out = { _: [], flags: {} };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) {
        out.flags[key] = true;
      } else {
        out.flags[key] = next;
        i++;
      }
    } else {
      out._.push(a);
    }
  }
  return out;
}

function die(msg) {
  console.error('错误: ' + msg);
  process.exit(1);
}

function requireToken() {
  if (!TOKEN) die('未设置环境变量 APPBUILDER_TOKEN（AppBuilder API Key）。');
}

// ---- HTTP 调用 -----------------------------------------------------------
async function callJSON(action, body) {
  requireToken();
  const url = `${BASE}/v2/knowledgeBase?Action=${action}`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + TOKEN,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  return handleResp(resp, action);
}

async function callMultipart(action, filePath, payload) {
  requireToken();
  if (!fs.existsSync(filePath)) die('文件不存在: ' + filePath);
  const url = `${BASE}/v2/knowledgeBase?Action=${action}`;
  const buf = fs.readFileSync(filePath);
  const name = filePath.split(/[\\/]/).pop();
  const form = new FormData();
  form.append('file', new Blob([buf]), name);
  form.append('payload', JSON.stringify(payload));
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + TOKEN }, // 让 fetch 自动带 multipart boundary
    body: form,
  });
  return handleResp(resp, action);
}

// 路径式接口（检索接口不是 ?Action= 风格，而是独立 path）
async function callPath(path, body, label) {
  requireToken();
  const url = `${BASE}${path}`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + TOKEN,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  return handleResp(resp, label || path);
}

async function handleResp(resp, action) {
  const text = await resp.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  if (!resp.ok) {
    console.error(`[${action}] HTTP ${resp.status}`);
    console.error(typeof data === 'string' ? data : JSON.stringify(data, null, 2));
    process.exit(1);
  }
  console.log(typeof data === 'string' ? data : JSON.stringify(data, null, 2));
  return data;
}

// 读取 --config 指向的 JSON 文件作为 processOption；否则用 template 兜底
function resolveProcessOption(flags) {
  if (flags.config) {
    const p = String(flags.config);
    if (!fs.existsSync(p)) die('--config 文件不存在: ' + p);
    try { return JSON.parse(fs.readFileSync(p, 'utf8')); }
    catch (e) { die('--config 不是合法 JSON: ' + e.message); }
  }
  return { template: flags.template ? String(flags.template) : 'default' };
}

// ---- 子命令 ---------------------------------------------------------------
const commands = {
  // 建库: create --name X [--desc D] [--type public|bes|vdb] [--cluster-id --es-user --es-pass --location] [--path-prefix P]
  async create(a) {
    const f = a.flags;
    if (!f.name) die('create 需要 --name');
    const type = f.type ? String(f.type) : 'public';
    const index = { type };
    if (type === 'bes' || type === 'vdb') {
      if (f['cluster-id']) index.clusterId = String(f['cluster-id']);
      if (f['es-user']) index.username = String(f['es-user']);
      if (f['es-pass']) index.password = String(f['es-pass']);
      if (f.location) index.location = String(f.location);
    }
    const config = { index };
    if (f['path-prefix']) config.catalogue = { pathPrefix: String(f['path-prefix']) };
    const body = { name: String(f.name), config };
    if (f.desc) body.description = String(f.desc);
    return callJSON('CreateKnowledgeBase', body);
  },

  // 详情: get <kbId>
  async get(a) {
    const id = a._[0];
    if (!id) die('get 需要知识库ID');
    return callJSON('DescribeKnowledgeBase', { id });
  },

  // 列表: list [--limit N] [--keyword K] [--marker M]
  async list(a) {
    const f = a.flags;
    const body = { maxKeys: f.limit ? Number(f.limit) : 10 };
    if (f.keyword) body.keyword = String(f.keyword);
    if (f.marker) body.marker = String(f.marker);
    return callJSON('DescribeKnowledgeBases', body);
  },

  // 修改: modify <kbId> [--name] [--desc] [--path-prefix]
  async modify(a) {
    const id = a._[0];
    if (!id) die('modify 需要知识库ID');
    const f = a.flags;
    const body = { id };
    if (f.name) body.name = String(f.name);
    if (f.desc) body.description = String(f.desc);
    if (f['path-prefix']) body.config = { catalogue: { pathPrefix: String(f['path-prefix']) } };
    return callJSON('ModifyKnowledgeBase', body);
  },

  // 删除: delete <kbId>   （不可逆，需 --yes 确认）
  async delete(a) {
    const id = a._[0];
    if (!id) die('delete 需要知识库ID');
    if (!a.flags.yes) die('删除知识库不可逆，请加 --yes 确认。');
    return callJSON('DeleteKnowledgeBase', { id });
  },

  // 导入url: doc-import <kbId> --url U [--url-depth 1] [--update-freq -1] [--format rawText] [--template default|--config f.json]
  async ['doc-import'](a) {
    const id = a._[0];
    const f = a.flags;
    if (!id) die('doc-import 需要知识库ID');
    if (!f.url) die('doc-import 需要 --url');
    const body = {
      id,
      source: {
        type: 'web',
        urlConfigs: [{
          url: String(f.url),
          urlDepth: f['url-depth'] ? Number(f['url-depth']) : 1,
          updateFrequency: f['update-freq'] ? Number(f['update-freq']) : -1,
        }],
      },
      contentFormat: f.format ? String(f.format) : 'rawText',
      processOption: resolveProcessOption(f),
    };
    return callJSON('CreateDocuments', body);
  },

  // 上传文件: doc-upload <kbId> --file path [--format rawText] [--template custom|--config f.json]
  async ['doc-upload'](a) {
    const id = a._[0];
    const f = a.flags;
    if (!id) die('doc-upload 需要知识库ID');
    if (!f.file) die('doc-upload 需要 --file');
    const payload = {
      id,
      source: { type: 'file' },
      contentFormat: f.format ? String(f.format) : 'rawText',
      processOption: resolveProcessOption(f),
    };
    return callMultipart('UploadDocuments', String(f.file), payload);
  },

  // 文档列表: doc-list <kbId> [--limit N] [--keyword K] [--marker M]
  async ['doc-list'](a) {
    const id = a._[0];
    if (!id) die('doc-list 需要知识库ID');
    const f = a.flags;
    const body = { knowledgeBaseId: id, maxKeys: f.limit ? Number(f.limit) : 10 };
    if (f.keyword) body.keyword = String(f.keyword);
    if (f.marker) body.marker = String(f.marker);
    return callJSON('DescribeDocuments', body);
  },

  // 删除文档: doc-delete <kbId> <docId>   （不可逆，需 --yes 确认）
  async ['doc-delete'](a) {
    const id = a._[0];
    const docId = a._[1];
    if (!id || !docId) die('doc-delete 需要 <知识库ID> <文档ID>');
    if (!a.flags.yes) die('删除文档不可逆，请加 --yes 确认。');
    return callJSON('DeleteDocument', { knowledgeBaseId: id, documentId: docId });
  },

  // 检索: search <kbId> --q "问题" [--top-k 6] [--type semantic|fulltext|hybrid] [--score 0.4]
  // 走 POST /v2/knowledgebases/search（路径式，非 ?Action=）
  async search(a) {
    const id = a._[0];
    const f = a.flags;
    if (!id) die('search 需要知识库ID');
    if (!f.q) die('search 需要 --q "检索内容"');
    const body = {
      query: String(f.q),
      knowledgebase_ids: [id],
      top_k: f['top-k'] ? Number(f['top-k']) : 6,
    };
    if (f.type) body.type = String(f.type);
    if (f.score) body.score_threshold = Number(f.score);
    return callPath('/v2/knowledgebases/search', body, 'search');
  },
};

// ---- 帮助与分发 -----------------------------------------------------------
const HELP = `千帆 AppBuilder 知识库 CLI（零依赖 Node 脚本）

鉴权: 需设置环境变量 APPBUILDER_TOKEN

知识库:
  create   --name <名> [--desc <描述>] [--type public|bes|vdb]
           [--cluster-id <id> --es-user <u> --es-pass <p> --location bj|bd|sz|gz]
           [--path-prefix </全部群组/..>]
  get      <知识库ID>
  list     [--limit 10] [--keyword <词>] [--marker <起始ID>]
  modify   <知识库ID> [--name <新名>] [--desc <描述>] [--path-prefix <路径>]
  delete   <知识库ID> --yes

文档:
  doc-import <知识库ID> --url <网址> [--url-depth 1] [--update-freq -1]
             [--format rawText] [--template default|custom|ppt|paper|resume|qaPair]
             [--config <processOption.json>]
  doc-upload <知识库ID> --file <本地文件> [--format rawText]
             [--template custom] [--config <processOption.json>]
  doc-list   <知识库ID> [--limit 10] [--keyword <词>] [--marker <起始ID>]
  doc-delete <知识库ID> <文档ID> --yes

检索:
  search     <知识库ID> --q "<检索内容>" [--top-k 6]
             [--type fulltext|semantic|hybrid] [--score 0.4]

复杂切片/解析策略见 ../reference.md，用 --config 传完整 processOption JSON。`;

async function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0];
  if (!cmd || cmd === 'help' || cmd === '--help' || cmd === '-h') {
    console.log(HELP);
    return;
  }
  const handler = commands[cmd];
  if (!handler) die(`未知命令: ${cmd}（运行 "node kb.js help" 查看用法）`);
  const a = parseArgs(argv.slice(1));
  await handler(a);
}

main().catch((e) => die(e && e.message ? e.message : String(e)));


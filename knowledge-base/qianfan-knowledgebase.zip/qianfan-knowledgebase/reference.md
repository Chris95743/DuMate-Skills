# processOption 参考（切片 / 解析 / 知识增强）

`doc-import` 和 `doc-upload` 的 `--config <file.json>` 接收一个完整的 `processOption` 对象。
不传 `--config` 时，脚本用 `{ "template": "<--template值，默认 default>" }`。

## 顶层字段

- `template` (string, 必填)：处理模板。
  - `default`：默认切分（系统自动规则）
  - `custom`：自定义切分（需配 `chunker`）
  - `ppt` / `paper` / `resume` / `qaPair`：按模板结构化导入
- `parser` (object, 可选)：解析方法。`{ "choices": [...] }`
  - 可选值（文字提取默认开启，不用写）：`layoutAnalysis`（版面分析）、`ocr`（光学字符识别）、`pageImageAnalysis`（文档图片解析）、`chartAnalysis`（图表解析）、`tableAnalysis`（表格深度解析）
- `knowledgeAugmentation` (object, 可选)：知识增强。`{ "choices": [...] }`
  - 可选值：`faq`、`spokenQuery`（问题生成）、`shortSummary`（段落摘要）、`spo`（三元组知识抽取）
- `chunker` (object, 可选)：切片策略，`template=custom` 时需填写。

## chunker 结构

- `choices` (array)：`separator`（标识符切片）| `pattern`（正则切片）| `onePage`（整文件切片），选其一或组合
- `prependInfo` (array, 可选)：切片附加元数据，`title`（标题）、`filename`（文件名）
- `separator` (object)：当 choices 含 `separator` 时
  - `separators` (array)：分隔符列表，可含分页符
  - `targetLength` (int)：分段最大长度
  - `overlapRate` (float)：重叠占比，推荐 0.25
- `pattern` (object)：当 choices 含 `pattern` 时
  - `regex` (string)：正则表达式
  - `markPosition` (string)：命中内容放置，`head`（前序）| `tail`（后序）| `drop`（丢弃）
  - `targetLength` (int)、`overlapRate` (float)

## 示例：自定义切片 + OCR + FAQ 增强

```json
{
  "template": "custom",
  "parser": { "choices": ["layoutAnalysis", "ocr"] },
  "chunker": {
    "choices": ["separator"],
    "separator": { "separators": ["。"], "targetLength": 300, "overlapRate": 0.25 },
    "prependInfo": ["title", "filename"]
  },
  "knowledgeAugmentation": { "choices": ["faq"] }
}
```

## 示例：正则切片

```json
{
  "template": "custom",
  "chunker": {
    "choices": ["pattern"],
    "pattern": { "regex": "^第.+章", "markPosition": "head", "targetLength": 500, "overlapRate": 0.25 }
  }
}
```

## 示例：默认切分（最简）

```json
{ "template": "default" }
```

## doc-import 的 source 说明

`doc-import` 会自动构造 `source`：
```json
{ "type": "web", "urlConfigs": [{ "url": "<--url>", "urlDepth": 1, "updateFrequency": -1 }] }
```
- `urlDepth`：`1` 只解析当前页；`2` 解析当前页及子网页（`--url-depth`）
- `updateFrequency`：`-1` 不自动更新；`1/3/7/30` 每 N 天更新（`--update-freq`）

`doc-upload` 的 source 固定为 `{ "type": "file" }`，文件通过 multipart 上传。
